import xbmcgui

xbmcgui.Dialog().ok("JioTV", "Addon Working Successfully")