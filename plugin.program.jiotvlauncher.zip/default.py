import os
os.system("am start -n com.jio.jioplay.tv/.activities.SplashActivity")